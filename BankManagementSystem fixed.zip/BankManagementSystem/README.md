# NovaBanK — Bank Management System
### Java Console Application | By Ashutosh Sahani

---

## Features
- Create Savings / Current accounts
- Deposit, Withdraw, Fund Transfer
- Full Transaction History
- PIN-based authentication (salted SHA-256)
- Update profile & Change PIN
- File-based persistent storage (no database needed)
- Admin panel (view all accounts, bank summary, deactivate accounts)
- Custom exception handling
- Input validation (email, phone, PIN format)

---

## Tech Stack
- **Language:** Java (JDK 11+)
- **Concepts:** OOP, Exception Handling, File I/O, Collections, Serialization
- **Security:** Salted SHA-256 PIN hashing, SecureRandom ID generation
- **Money:** `BigDecimal` for all financial calculations (no floating-point errors)
- **Storage:** Binary file persistence (.dat files)

---

## Project Structure
```
BankManagementSystem/
├── src/
│   ├── Main.java
│   └── bank/
│       ├── model/
│       │   ├── Account.java
│       │   └── Transaction.java
│       ├── service/
│       │   └── BankService.java
│       ├── exception/
│       │   └── BankException.java
│       ├── util/
│       │   ├── AdminConfig.java
│       │   ├── BankUtils.java
│       │   └── FileStorage.java
│       └── ui/
│           └── ConsoleUI.java
└── data/  (auto-created at runtime)
    ├── accounts.dat
    ├── transactions.dat
    └── admin.properties  ← hashed admin password (never share)
```

---

## How to Run

### Compile
```bash
cd src
javac -d ../out bank/model/*.java bank/exception/*.java bank/util/*.java bank/service/*.java bank/ui/*.java Main.java
```

### Run
```bash
cd ../out
java Main
```

---

## Admin Panel
- On **first run**, you will be prompted to set an admin password (min 6 characters).
- The password is stored as a **salted hash** in `data/admin.properties` — never in plaintext.
- You can change the admin password from inside the Admin Panel (option 4).

---

## Sample Usage
1. Create an account → note your Account Number
2. Login with Account Number + PIN
3. Deposit / Withdraw / Transfer
4. View transaction history

---

## Security Improvements (v2)
| Issue | Fix |
|---|---|
| Hardcoded `admin123` password | First-run setup, hashed in `admin.properties` |
| SHA-256 without salt (rainbow table vulnerable) | Salted SHA-256: `salt:hash` format |
| `java.util.Random` for IDs | `SecureRandom` — cryptographically unpredictable |
| `double` for money (floating-point errors) | `BigDecimal` with `HALF_UP` rounding |
| All transactions loaded in memory on startup | Lazy-loaded per query |

---

## Key Java Concepts Demonstrated
| Concept | Where Used |
|---|---|
| OOP (Classes, Encapsulation) | Account, Transaction models |
| Inheritance / Custom Exceptions | BankException hierarchy |
| Collections (HashMap, ArrayList) | Account & transaction storage |
| File I/O + Serialization | FileStorage utility |
| Salted SHA-256 + SecureRandom | PIN & ID security in BankUtils |
| Stream API | Transaction filtering & stats |
| Enums | AccountType, TransactionType |
| BigDecimal | All monetary calculations |
