package bank.service;

import bank.exception.BankException;
import bank.model.Account;
import bank.model.Transaction;
import bank.util.BankUtils;
import bank.util.FileStorage;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

public class BankService {

    private final Map<String, Account> accounts;

    public BankService() {
        this.accounts = FileStorage.loadAccounts();
    }

    // ─── Account Operations ───────────────────────────────────────

    public Account createAccount(String holderName, String email, String phone,
                                  String pin, BigDecimal initialDeposit, Account.AccountType type) throws BankException {
        if (!BankUtils.isValidEmail(email))
            throw new BankException("Invalid email address.");
        if (!BankUtils.isValidPhone(phone))
            throw new BankException("Invalid phone number. Must be 10 digits starting with 6-9.");
        if (!BankUtils.isValidPin(pin))
            throw new BankException("PIN must be exactly 4 digits.");
        if (initialDeposit.compareTo(new BigDecimal("500")) < 0)
            throw new BankException("Minimum initial deposit is ₹500.");

        String accountNumber = generateUniqueAccountNumber();
        String hashedPin = BankUtils.hashPin(pin);

        Account account = new Account(accountNumber, holderName, email, phone,
                hashedPin, initialDeposit, type);
        accounts.put(accountNumber, account);
        FileStorage.saveAccounts(accounts);

        // Log initial deposit transaction
        Transaction txn = new Transaction(
            BankUtils.generateTransactionId(), accountNumber,
            Transaction.TransactionType.DEPOSIT, initialDeposit, initialDeposit,
            "Account opening deposit"
        );
        appendTransaction(txn);

        return account;
    }

    public Account getAccount(String accountNumber) throws BankException {
        Account account = accounts.get(accountNumber);
        if (account == null)
            throw new BankException("Account not found: " + accountNumber);
        return account;
    }

    public void verifyPin(String accountNumber, String pin) throws BankException {
        Account account = getAccount(accountNumber);
        if (!BankUtils.verifyPin(pin, account.getPin()))
            throw new BankException("Incorrect PIN. Please try again.");
        if (!account.isActive())
            throw new BankException("Account is inactive. Contact support.");
    }

    public void updateAccount(String accountNumber, String name, String email, String phone) throws BankException {
        Account account = getAccount(accountNumber);
        if (name != null && !name.isBlank()) account.setHolderName(name);
        if (email != null && !email.isBlank()) {
            if (!BankUtils.isValidEmail(email)) throw new BankException("Invalid email.");
            account.setEmail(email);
        }
        if (phone != null && !phone.isBlank()) {
            if (!BankUtils.isValidPhone(phone)) throw new BankException("Invalid phone.");
            account.setPhone(phone);
        }
        FileStorage.saveAccounts(accounts);
    }

    public void changePin(String accountNumber, String oldPin, String newPin) throws BankException {
        Account account = getAccount(accountNumber);
        if (!BankUtils.verifyPin(oldPin, account.getPin()))
            throw new BankException("Incorrect current PIN.");
        if (!BankUtils.isValidPin(newPin))
            throw new BankException("New PIN must be exactly 4 digits.");
        account.setPin(BankUtils.hashPin(newPin));
        FileStorage.saveAccounts(accounts);
    }

    public void deactivateAccount(String accountNumber) throws BankException {
        Account account = getAccount(accountNumber);
        account.setActive(false);
        FileStorage.saveAccounts(accounts);
    }

    // ─── Transaction Operations ───────────────────────────────────

    public Transaction deposit(String accountNumber, BigDecimal amount) throws BankException {
        if (amount.compareTo(BigDecimal.ZERO) <= 0)
            throw new BankException("Deposit amount must be greater than 0.");
        if (amount.compareTo(new BigDecimal("1000000")) > 0)
            throw new BankException("Maximum deposit per transaction is ₹10,00,000.");

        Account account = getAccount(accountNumber);
        if (!account.isActive()) throw new BankException("Account is inactive.");

        BigDecimal newBalance = account.getBalance().add(amount).setScale(2, RoundingMode.HALF_UP);
        account.setBalance(newBalance);
        FileStorage.saveAccounts(accounts);

        Transaction txn = new Transaction(
            BankUtils.generateTransactionId(), accountNumber,
            Transaction.TransactionType.DEPOSIT, amount, newBalance, "Cash deposit"
        );
        appendTransaction(txn);
        return txn;
    }

    public Transaction withdraw(String accountNumber, BigDecimal amount) throws BankException {
        if (amount.compareTo(BigDecimal.ZERO) <= 0)
            throw new BankException("Withdrawal amount must be greater than 0.");

        Account account = getAccount(accountNumber);
        if (!account.isActive()) throw new BankException("Account is inactive.");

        BigDecimal minBalance = account.getAccountType() == Account.AccountType.SAVINGS
            ? new BigDecimal("500") : new BigDecimal("1000");

        if (account.getBalance().subtract(amount).compareTo(minBalance) < 0)
            throw new BankException(String.format(
                "Insufficient funds. Minimum balance of ₹%s must be maintained.", minBalance.toPlainString()));

        BigDecimal newBalance = account.getBalance().subtract(amount).setScale(2, RoundingMode.HALF_UP);
        account.setBalance(newBalance);
        FileStorage.saveAccounts(accounts);

        Transaction txn = new Transaction(
            BankUtils.generateTransactionId(), accountNumber,
            Transaction.TransactionType.WITHDRAWAL, amount, newBalance, "Cash withdrawal"
        );
        appendTransaction(txn);
        return txn;
    }

    public void transfer(String fromAccNum, String toAccNum, BigDecimal amount) throws BankException {
        if (fromAccNum.equals(toAccNum))
            throw new BankException("Cannot transfer to the same account.");
        if (amount.compareTo(BigDecimal.ZERO) <= 0)
            throw new BankException("Transfer amount must be greater than 0.");

        Account from = getAccount(fromAccNum);
        Account to   = getAccount(toAccNum);

        if (!from.isActive()) throw new BankException("Your account is inactive.");
        if (!to.isActive())   throw new BankException("Recipient account is inactive.");

        BigDecimal minBalance = from.getAccountType() == Account.AccountType.SAVINGS
            ? new BigDecimal("500") : new BigDecimal("1000");

        if (from.getBalance().subtract(amount).compareTo(minBalance) < 0)
            throw new BankException(String.format(
                "Insufficient funds. Minimum balance ₹%s must be maintained.", minBalance.toPlainString()));

        BigDecimal fromNew = from.getBalance().subtract(amount).setScale(2, RoundingMode.HALF_UP);
        BigDecimal toNew   = to.getBalance().add(amount).setScale(2, RoundingMode.HALF_UP);
        from.setBalance(fromNew);
        to.setBalance(toNew);
        FileStorage.saveAccounts(accounts);

        appendTransaction(new Transaction(BankUtils.generateTransactionId(), fromAccNum,
            Transaction.TransactionType.TRANSFER_OUT, amount, fromNew, "Transfer to " + toAccNum));
        appendTransaction(new Transaction(BankUtils.generateTransactionId(), toAccNum,
            Transaction.TransactionType.TRANSFER_IN, amount, toNew, "Transfer from " + fromAccNum));
    }

    // ─── Transaction History (lazy — only loads for one account) ──

    public List<Transaction> getTransactionHistory(String accountNumber, int limit) throws BankException {
        getAccount(accountNumber); // validate account exists
        List<Transaction> all = FileStorage.loadTransactions();
        List<Transaction> filtered = all.stream()
            .filter(t -> t.getAccountNumber().equals(accountNumber))
            .collect(Collectors.toList());
        Collections.reverse(filtered);
        if (limit > 0 && filtered.size() > limit)
            return filtered.subList(0, limit);
        return filtered;
    }

    // ─── Admin Operations ─────────────────────────────────────────

    public List<Account> getAllAccounts() {
        return new ArrayList<>(accounts.values());
    }

    public BigDecimal getTotalDeposits() {
        return accounts.values().stream()
            .map(Account::getBalance)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    // ─── Helpers ──────────────────────────────────────────────────

    private String generateUniqueAccountNumber() {
        String accNum;
        do { accNum = BankUtils.generateAccountNumber(); }
        while (accounts.containsKey(accNum));
        return accNum;
    }

    /** Appends a single transaction to the file without loading all into memory. */
    private void appendTransaction(Transaction txn) {
        List<Transaction> all = FileStorage.loadTransactions();
        all.add(txn);
        FileStorage.saveTransactions(all);
    }
}
