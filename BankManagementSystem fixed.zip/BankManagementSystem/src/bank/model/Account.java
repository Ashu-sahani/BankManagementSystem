package bank.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Account implements Serializable {
    private static final long serialVersionUID = 2L;

    public enum AccountType { SAVINGS, CURRENT }

    private String accountNumber;
    private String holderName;
    private String email;
    private String phone;
    private String pin; // salted hash: "salt:hash"
    private BigDecimal balance;
    private AccountType accountType;
    private boolean isActive;
    private String createdAt;

    public Account(String accountNumber, String holderName, String email,
                   String phone, String pin, BigDecimal initialDeposit, AccountType accountType) {
        this.accountNumber = accountNumber;
        this.holderName = holderName;
        this.email = email;
        this.phone = phone;
        this.pin = pin;
        this.balance = initialDeposit;
        this.accountType = accountType;
        this.isActive = true;
        this.createdAt = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
    }

    public String getAccountNumber() { return accountNumber; }
    public String getHolderName()    { return holderName; }
    public String getEmail()         { return email; }
    public String getPhone()         { return phone; }
    public String getPin()           { return pin; }
    public BigDecimal getBalance()   { return balance; }
    public AccountType getAccountType() { return accountType; }
    public boolean isActive()        { return isActive; }
    public String getCreatedAt()     { return createdAt; }

    public void setBalance(BigDecimal balance) { this.balance = balance; }
    public void setActive(boolean active)      { isActive = active; }
    public void setPin(String pin)             { this.pin = pin; }
    public void setHolderName(String name)     { this.holderName = name; }
    public void setEmail(String email)         { this.email = email; }
    public void setPhone(String phone)         { this.phone = phone; }

    @Override
    public String toString() {
        return String.format(
            "\n╔══════════════════════════════════════╗\n" +
            "  Account Number : %s\n" +
            "  Holder Name    : %s\n" +
            "  Email          : %s\n" +
            "  Phone          : %s\n" +
            "  Account Type   : %s\n" +
            "  Balance        : ₹%s\n" +
            "  Status         : %s\n" +
            "  Created At     : %s\n" +
            "╚══════════════════════════════════════╝",
            accountNumber, holderName, email, phone,
            accountType, balance.toPlainString(),
            isActive ? "Active" : "Inactive", createdAt
        );
    }
}
