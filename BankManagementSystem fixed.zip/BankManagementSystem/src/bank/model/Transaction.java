package bank.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction implements Serializable {
    private static final long serialVersionUID = 2L;

    public enum TransactionType { DEPOSIT, WITHDRAWAL, TRANSFER_IN, TRANSFER_OUT }

    private String transactionId;
    private String accountNumber;
    private TransactionType type;
    private BigDecimal amount;
    private BigDecimal balanceAfter;
    private String description;
    private String timestamp;

    public Transaction(String transactionId, String accountNumber, TransactionType type,
                       BigDecimal amount, BigDecimal balanceAfter, String description) {
        this.transactionId = transactionId;
        this.accountNumber = accountNumber;
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
        this.description = description;
        this.timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
    }

    public String getTransactionId()  { return transactionId; }
    public String getAccountNumber()  { return accountNumber; }
    public TransactionType getType()  { return type; }
    public BigDecimal getAmount()     { return amount; }
    public BigDecimal getBalanceAfter() { return balanceAfter; }
    public String getDescription()    { return description; }
    public String getTimestamp()      { return timestamp; }

    @Override
    public String toString() {
        String sign = (type == TransactionType.DEPOSIT || type == TransactionType.TRANSFER_IN) ? "+" : "-";
        return String.format("  [%s] %-14s | %s₹%-10s | Balance: ₹%-10s | %s | %s",
            transactionId, type, sign, amount.toPlainString(),
            balanceAfter.toPlainString(), description, timestamp);
    }
}
