package bank.ui;

import bank.exception.BankException;
import bank.model.Account;
import bank.model.Transaction;
import bank.service.BankService;
import bank.util.AdminConfig;
import bank.util.BankUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;

public class ConsoleUI {

    private final BankService bankService;
    private final Scanner scanner;

    public ConsoleUI() {
        this.bankService = new BankService();
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        ensureAdminConfigured();
        printWelcomeBanner();
        while (true) {
            showMainMenu();
            int choice = readInt("  Enter choice: ");
            switch (choice) {
                case 1 -> createAccount();
                case 2 -> login();
                case 3 -> adminPanel();
                case 0 -> { System.out.println("\n  Thank you for using NovaBanK. Goodbye!\n"); return; }
                default -> System.out.println("  [!] Invalid choice. Try again.");
            }
        }
    }

    // ─── First-run Admin Setup ────────────────────────────────────

    private void ensureAdminConfigured() {
        if (!AdminConfig.isConfigured()) {
            System.out.println("\n  ╔══════════════════════════════════════╗");
            System.out.println("  ║     FIRST-RUN ADMIN SETUP            ║");
            System.out.println("  ╚══════════════════════════════════════╝");
            System.out.println("  No admin password found. Please set one now.");
            String pass;
            while (true) {
                System.out.print("  Set admin password (min 6 chars): ");
                pass = scanner.nextLine().trim();
                if (pass.length() >= 6) break;
                System.out.println("  [!] Password too short. Must be at least 6 characters.");
            }
            System.out.print("  Confirm password: ");
            String confirm = scanner.nextLine().trim();
            if (!pass.equals(confirm)) {
                System.out.println("  [!] Passwords do not match. Restart to try again.");
                System.exit(1);
            }
            AdminConfig.setAdminPassword(pass);
            System.out.println("  ✅ Admin password set successfully!\n");
        }
    }

    // ─── Menus ────────────────────────────────────────────────────

    private void showMainMenu() {
        System.out.println("\n  ╔══════════════════════════════╗");
        System.out.println("  ║         MAIN MENU            ║");
        System.out.println("  ╠══════════════════════════════╣");
        System.out.println("  ║  1. Create New Account       ║");
        System.out.println("  ║  2. Login to Account         ║");
        System.out.println("  ║  3. Admin Panel              ║");
        System.out.println("  ║  0. Exit                     ║");
        System.out.println("  ╚══════════════════════════════╝");
    }

    private void showAccountMenu(String accountNumber) {
        try {
            Account account = bankService.getAccount(accountNumber);
            System.out.println("\n  Welcome, " + account.getHolderName() + "!");
            System.out.printf("  Balance: ₹%s%n", account.getBalance().toPlainString());
            System.out.println("\n  ╔══════════════════════════════╗");
            System.out.println("  ║         ACCOUNT MENU         ║");
            System.out.println("  ╠══════════════════════════════╣");
            System.out.println("  ║  1. Deposit                  ║");
            System.out.println("  ║  2. Withdraw                 ║");
            System.out.println("  ║  3. Transfer Funds           ║");
            System.out.println("  ║  4. Transaction History      ║");
            System.out.println("  ║  5. Account Details          ║");
            System.out.println("  ║  6. Update Profile           ║");
            System.out.println("  ║  7. Change PIN               ║");
            System.out.println("  ║  0. Logout                   ║");
            System.out.println("  ╚══════════════════════════════╝");
        } catch (BankException e) {
            System.out.println("  [ERROR] " + e.getMessage());
        }
    }

    // ─── Account Creation ─────────────────────────────────────────

    private void createAccount() {
        BankUtils.printHeader("CREATE NEW ACCOUNT");
        try {
            System.out.print("  Full Name       : ");
            String name = scanner.nextLine().trim();
            if (name.isBlank()) { System.out.println("  [!] Name cannot be empty."); return; }

            System.out.print("  Email           : ");
            String email = scanner.nextLine().trim();

            System.out.print("  Phone           : ");
            String phone = scanner.nextLine().trim();

            System.out.print("  Set 4-digit PIN : ");
            String pin = scanner.nextLine().trim();

            System.out.print("  Initial Deposit : ₹");
            BigDecimal deposit = readBigDecimal();

            System.out.println("  Account Type    : 1. Savings  2. Current");
            int typeChoice = readInt("  Choose (1/2)    : ");
            Account.AccountType type = (typeChoice == 2) ? Account.AccountType.CURRENT : Account.AccountType.SAVINGS;

            Account account = bankService.createAccount(name, email, phone, pin, deposit, type);
            System.out.println("\n  ✅ Account created successfully!");
            System.out.println("  Your Account Number: " + account.getAccountNumber());
            System.out.println("  Please note it down safely.");

        } catch (BankException e) {
            System.out.println("  [ERROR] " + e.getMessage());
        }
    }

    // ─── Login ────────────────────────────────────────────────────

    private void login() {
        BankUtils.printHeader("ACCOUNT LOGIN");
        System.out.print("  Account Number : ");
        String accNum = scanner.nextLine().trim().toUpperCase();
        System.out.print("  PIN            : ");
        String pin = scanner.nextLine().trim();

        try {
            bankService.verifyPin(accNum, pin);
            System.out.println("  ✅ Login successful!");
            accountDashboard(accNum);
        } catch (BankException e) {
            System.out.println("  [ERROR] " + e.getMessage());
        }
    }

    // ─── Account Dashboard ────────────────────────────────────────

    private void accountDashboard(String accountNumber) {
        while (true) {
            showAccountMenu(accountNumber);
            int choice = readInt("  Enter choice: ");
            switch (choice) {
                case 1 -> deposit(accountNumber);
                case 2 -> withdraw(accountNumber);
                case 3 -> transfer(accountNumber);
                case 4 -> showTransactionHistory(accountNumber);
                case 5 -> showAccountDetails(accountNumber);
                case 6 -> updateProfile(accountNumber);
                case 7 -> changePin(accountNumber);
                case 0 -> { System.out.println("  Logged out successfully."); return; }
                default -> System.out.println("  [!] Invalid choice.");
            }
        }
    }

    private void deposit(String accountNumber) {
        BankUtils.printHeader("DEPOSIT");
        System.out.print("  Enter amount: ₹");
        BigDecimal amount = readBigDecimal();
        try {
            Transaction txn = bankService.deposit(accountNumber, amount);
            System.out.printf("  ✅ ₹%s deposited successfully!%n", amount.toPlainString());
            System.out.printf("  New Balance: ₹%s%n", txn.getBalanceAfter().toPlainString());
        } catch (BankException e) {
            System.out.println("  [ERROR] " + e.getMessage());
        }
    }

    private void withdraw(String accountNumber) {
        BankUtils.printHeader("WITHDRAWAL");
        System.out.print("  Enter amount: ₹");
        BigDecimal amount = readBigDecimal();
        try {
            Transaction txn = bankService.withdraw(accountNumber, amount);
            System.out.printf("  ✅ ₹%s withdrawn successfully!%n", amount.toPlainString());
            System.out.printf("  Remaining Balance: ₹%s%n", txn.getBalanceAfter().toPlainString());
        } catch (BankException e) {
            System.out.println("  [ERROR] " + e.getMessage());
        }
    }

    private void transfer(String accountNumber) {
        BankUtils.printHeader("FUND TRANSFER");
        System.out.print("  Recipient Account Number : ");
        String toAcc = scanner.nextLine().trim().toUpperCase();
        System.out.print("  Amount to Transfer       : ₹");
        BigDecimal amount = readBigDecimal();
        System.out.print("  Confirm transfer? (yes/no): ");
        String confirm = scanner.nextLine().trim();
        if (!confirm.equalsIgnoreCase("yes")) {
            System.out.println("  Transfer cancelled.");
            return;
        }
        try {
            bankService.transfer(accountNumber, toAcc, amount);
            System.out.printf("  ✅ ₹%s transferred to %s successfully!%n", amount.toPlainString(), toAcc);
        } catch (BankException e) {
            System.out.println("  [ERROR] " + e.getMessage());
        }
    }

    private void showTransactionHistory(String accountNumber) {
        BankUtils.printHeader("TRANSACTION HISTORY");
        System.out.print("  Show last how many? (0 = all): ");
        int limit = readInt("");
        try {
            List<Transaction> txns = bankService.getTransactionHistory(accountNumber, limit);
            if (txns.isEmpty()) { System.out.println("  No transactions found."); return; }
            System.out.println();
            txns.forEach(System.out::println);
            System.out.println("\n  Total: " + txns.size() + " transaction(s)");
        } catch (BankException e) {
            System.out.println("  [ERROR] " + e.getMessage());
        }
    }

    private void showAccountDetails(String accountNumber) {
        BankUtils.printHeader("ACCOUNT DETAILS");
        try {
            System.out.println(bankService.getAccount(accountNumber));
        } catch (BankException e) {
            System.out.println("  [ERROR] " + e.getMessage());
        }
    }

    private void updateProfile(String accountNumber) {
        BankUtils.printHeader("UPDATE PROFILE");
        System.out.println("  (Press Enter to skip a field)");
        System.out.print("  New Name  : "); String name  = scanner.nextLine().trim();
        System.out.print("  New Email : "); String email = scanner.nextLine().trim();
        System.out.print("  New Phone : "); String phone = scanner.nextLine().trim();
        try {
            bankService.updateAccount(accountNumber, name, email, phone);
            System.out.println("  ✅ Profile updated successfully!");
        } catch (BankException e) {
            System.out.println("  [ERROR] " + e.getMessage());
        }
    }

    private void changePin(String accountNumber) {
        BankUtils.printHeader("CHANGE PIN");
        System.out.print("  Current PIN : "); String oldPin = scanner.nextLine().trim();
        System.out.print("  New PIN     : "); String newPin = scanner.nextLine().trim();
        try {
            bankService.changePin(accountNumber, oldPin, newPin);
            System.out.println("  ✅ PIN changed successfully!");
        } catch (BankException e) {
            System.out.println("  [ERROR] " + e.getMessage());
        }
    }

    // ─── Admin Panel ──────────────────────────────────────────────

    private void adminPanel() {
        System.out.print("\n  Admin Password: ");
        String pass = scanner.nextLine().trim();
        if (!AdminConfig.verifyAdminPassword(pass)) {
            System.out.println("  [!] Access denied.");
            return;
        }
        BankUtils.printHeader("ADMIN PANEL");
        System.out.println("  1. View All Accounts");
        System.out.println("  2. Bank Summary");
        System.out.println("  3. Deactivate Account");
        System.out.println("  4. Change Admin Password");
        System.out.println("  0. Back");
        int choice = readInt("  Choice: ");
        switch (choice) {
            case 1 -> {
                List<Account> all = bankService.getAllAccounts();
                if (all.isEmpty()) { System.out.println("  No accounts found."); break; }
                all.forEach(a -> System.out.printf("  %-15s | %-20s | ₹%-12s | %s%n",
                    a.getAccountNumber(), a.getHolderName(),
                    a.getBalance().toPlainString(), a.isActive() ? "Active" : "Inactive"));
            }
            case 2 -> {
                List<Account> all = bankService.getAllAccounts();
                System.out.println("  Total Accounts : " + all.size());
                System.out.printf("  Total Deposits : ₹%s%n", bankService.getTotalDeposits().toPlainString());
            }
            case 3 -> {
                System.out.print("  Account to deactivate: ");
                String acc = scanner.nextLine().trim().toUpperCase();
                try {
                    bankService.deactivateAccount(acc);
                    System.out.println("  ✅ Account deactivated.");
                } catch (BankException e) {
                    System.out.println("  [ERROR] " + e.getMessage());
                }
            }
            case 4 -> {
                System.out.print("  New admin password (min 6 chars): ");
                String newPass = scanner.nextLine().trim();
                if (newPass.length() < 6) {
                    System.out.println("  [!] Password too short.");
                } else {
                    AdminConfig.setAdminPassword(newPass);
                    System.out.println("  ✅ Admin password updated.");
                }
            }
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────

    private int readInt(String prompt) {
        if (!prompt.isBlank()) System.out.print(prompt);
        try { return Integer.parseInt(scanner.nextLine().trim()); }
        catch (NumberFormatException e) { return -1; }
    }

    private BigDecimal readBigDecimal() {
        try {
            return new BigDecimal(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [!] Invalid amount. Using 0.");
            return BigDecimal.ZERO;
        }
    }

    private void printWelcomeBanner() {
        System.out.println("\n  ╔══════════════════════════════════════╗");
        System.out.println("  ║                                      ║");
        System.out.println("  ║        Welcome to NovaBanK           ║");
        System.out.println("  ║     Secure. Simple. Reliable.        ║");
        System.out.println("  ║                                      ║");
        System.out.println("  ╚══════════════════════════════════════╝");
    }
}
