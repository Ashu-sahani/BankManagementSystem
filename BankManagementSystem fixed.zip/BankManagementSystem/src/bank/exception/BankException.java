package bank.exception;

public class BankException extends Exception {
    public BankException(String message) {
        super(message);
    }
}

class InsufficientFundsException extends BankException {
    public InsufficientFundsException(double required, double available) {
        super(String.format("Insufficient funds. Required: ₹%.2f, Available: ₹%.2f", required, available));
    }
}

class AccountNotFoundException extends BankException {
    public AccountNotFoundException(String accountNumber) {
        super("Account not found: " + accountNumber);
    }
}

class AccountInactiveException extends BankException {
    public AccountInactiveException(String accountNumber) {
        super("Account is inactive: " + accountNumber);
    }
}

class InvalidPinException extends BankException {
    public InvalidPinException() {
        super("Invalid PIN. Please try again.");
    }
}

class DuplicateAccountException extends BankException {
    public DuplicateAccountException(String accountNumber) {
        super("Account already exists: " + accountNumber);
    }
}
