package bank.util;

import bank.model.Account;
import bank.model.Transaction;

import java.io.*;
import java.util.*;

public class FileStorage {

    private static final String DATA_DIR = "data/";
    private static final String ACCOUNTS_FILE = DATA_DIR + "accounts.dat";
    private static final String TRANSACTIONS_FILE = DATA_DIR + "transactions.dat";

    static {
        new File(DATA_DIR).mkdirs();
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Account> loadAccounts() {
        File file = new File(ACCOUNTS_FILE);
        if (!file.exists()) return new HashMap<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (Map<String, Account>) ois.readObject();
        } catch (Exception e) {
            return new HashMap<>();
        }
    }

    public static void saveAccounts(Map<String, Account> accounts) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ACCOUNTS_FILE))) {
            oos.writeObject(accounts);
        } catch (IOException e) {
            System.out.println("  [ERROR] Could not save account data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public static List<Transaction> loadTransactions() {
        File file = new File(TRANSACTIONS_FILE);
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Transaction>) ois.readObject();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public static void saveTransactions(List<Transaction> transactions) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(TRANSACTIONS_FILE))) {
            oos.writeObject(transactions);
        } catch (IOException e) {
            System.out.println("  [ERROR] Could not save transaction data: " + e.getMessage());
        }
    }
}
