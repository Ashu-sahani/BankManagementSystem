package bank.util;

import java.io.*;
import java.util.Properties;

/**
 * Manages admin credentials stored in a config file (not hardcoded).
 * On first run, prompts to set a password and stores it as a salted hash.
 */
public class AdminConfig {

    private static final String CONFIG_FILE = "data/admin.properties";
    private static final String DEFAULT_HASH_KEY = "admin.password.hash";

    /** Returns true if the given password matches the stored admin hash. */
    public static boolean verifyAdminPassword(String input) {
        String storedHash = loadHash();
        if (storedHash == null) return false;
        return BankUtils.verifyPin(input, storedHash); // reuses same salted verify
    }

    /** Returns true if an admin password has been configured. */
    public static boolean isConfigured() {
        return loadHash() != null;
    }

    /** Saves a new admin password (hashed). */
    public static void setAdminPassword(String plainPassword) {
        String hash = BankUtils.hashPin(plainPassword);
        Properties props = new Properties();
        props.setProperty(DEFAULT_HASH_KEY, hash);
        new File("data").mkdirs();
        try (FileOutputStream fos = new FileOutputStream(CONFIG_FILE)) {
            props.store(fos, "NovaBanK Admin Config — do not share this file");
        } catch (IOException e) {
            System.out.println("  [ERROR] Could not save admin config: " + e.getMessage());
        }
    }

    private static String loadHash() {
        File file = new File(CONFIG_FILE);
        if (!file.exists()) return null;
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(file)) {
            props.load(fis);
            return props.getProperty(DEFAULT_HASH_KEY);
        } catch (IOException e) {
            return null;
        }
    }
}
