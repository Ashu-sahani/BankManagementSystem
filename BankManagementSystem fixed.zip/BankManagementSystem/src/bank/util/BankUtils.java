package bank.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class BankUtils {

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    // ─── PIN Hashing (salted SHA-256) ─────────────────────────────

    public static String hashPin(String pin) {
        byte[] salt = new byte[16];
        SECURE_RANDOM.nextBytes(salt);
        String saltBase64 = Base64.getEncoder().encodeToString(salt);
        String hash = sha256(saltBase64 + pin);
        return saltBase64 + ":" + hash; // store as "salt:hash"
    }

    public static boolean verifyPin(String inputPin, String storedValue) {
        if (storedValue == null || !storedValue.contains(":")) return false;
        String[] parts = storedValue.split(":", 2);
        String saltBase64 = parts[0];
        String expectedHash = parts[1];
        return sha256(saltBase64 + inputPin).equals(expectedHash);
    }

    private static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes());
            StringBuilder hexStr = new StringBuilder();
            for (byte b : hash) hexStr.append(String.format("%02x", b));
            return hexStr.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    // ─── ID Generation (SecureRandom) ─────────────────────────────

    public static String generateAccountNumber() {
        StringBuilder sb = new StringBuilder("ACC");
        for (int i = 0; i < 7; i++) sb.append(SECURE_RANDOM.nextInt(10));
        return sb.toString();
    }

    public static String generateTransactionId() {
        StringBuilder sb = new StringBuilder("TXN");
        for (int i = 0; i < 8; i++) sb.append(SECURE_RANDOM.nextInt(10));
        return sb.toString();
    }

    // ─── Validation ───────────────────────────────────────────────

    public static boolean isValidEmail(String email) {
        return email != null && email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }

    public static boolean isValidPhone(String phone) {
        return phone != null && phone.matches("^[6-9]\\d{9}$");
    }

    public static boolean isValidPin(String pin) {
        return pin != null && pin.matches("\\d{4}");
    }

    // ─── Console Helpers ──────────────────────────────────────────

    public static void printDivider() {
        System.out.println("  ----------------------------------------");
    }

    public static void printHeader(String title) {
        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.printf("  %-38s%n", "  " + title);
        System.out.println("╚══════════════════════════════════════╝");
    }
}
