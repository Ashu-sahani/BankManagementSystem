import bank.ui.ConsoleUI;

public class Main {
    public static void main(String[] args) {
        new ConsoleUI().start();
    }
}
